package App::RecordStream::DomainLanguage::Valuation;

use strict;
use warnings;

# marker

1;
